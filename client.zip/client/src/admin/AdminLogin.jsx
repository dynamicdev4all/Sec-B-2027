import React, { useState } from 'react'
import adminLogin from '../api/adminLoginApi';
import { useNavigate } from 'react-router-dom';

const AdminLogin = () => {
    // react - useState hook

    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [pass, setPass] = useState("");

    const handleLogin = ()=>{
        const loginRes = adminLogin(email, pass);
        if(loginRes === "Login Success"){
            //Navigate to Dashboard
            navigate("/adminDashboard")
        }else{
            //Show error
        }
    }
  return (
    <div>
        <form onSubmit={handleLogin}>
            <input type="email" 
            name="adminEmail" 
            id="" 
            onChange={(e)=>setEmail(e.target.value)}
            />

            <input type="password" 
            name="adminPass" 
            id="" 
             onChange={(e)=>setPass(e.target.value)}
            />
            <button type="submit">Login Now</button>
        </form>
    </div>
  )
}

export default AdminLogin