import { useState } from 'react'
import {BrowserRouter, Routes, Route} from "react-router-dom"
import './App.css'
import AdminLogin from './admin/AdminLogin'
import AdminDashboard from './admin/AdminDashboard'
import AdminRegistration from './admin/AdminRegistration'
import FourOFour from './FourOFour'

function App() {

  return (
    <>
    <BrowserRouter>
      <Routes>
        <Route path='/' Component={AdminLogin}/>
        <Route path='/adminDashboard' Component={AdminDashboard}/>
        <Route path='/adminRegistration' Component={AdminRegistration}/>
        <Route path='/*' Component={FourOFour}/>
      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
