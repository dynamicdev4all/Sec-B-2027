import axios from "axios";

const ajay = axios.create({
    baseURL : "http://localhost:1212/"
});

export default ajay;