import axios from "axios"
import ajay from "./springaApi"


const adminLogin = (email, password)=>{
    //  const res2 = axios.post("http://localhost:1212/admin/login/{id}", {
    //     email,
    //     password
    // })

    const res = ajay.post("/admin/login/{id}", {
        email,
        password
    })

    return res.data;
}

export default adminLogin